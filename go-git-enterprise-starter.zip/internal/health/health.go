package health

func OK() bool { return true }
